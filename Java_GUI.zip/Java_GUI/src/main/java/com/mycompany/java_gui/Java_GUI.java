/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.java_gui;

/**
 *
 * @author Lenovo
 */
public class Java_GUI {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new Register_Frame();
        });
    }
}
