/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai_2;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Scanner;

/**
 *
 * @author Lenovo
 */
public class Bai_2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        int[] dem = new int[n];
        LinkedHashMap<User,Integer> mp = new LinkedHashMap();
        ArrayList<User> uss = new ArrayList();
        ArrayList<String> sl_dn = new ArrayList();
        ArrayList<String> sl_mk = new ArrayList(); // dung
        for(int i=0 ; i<n ; i++)
        {
            String[] str = sc.nextLine().split("\\s+");
            String dangnhap = str[0];
            String matkhau = str[1];
            User us = new User(i,dangnhap,matkhau);
            uss.add(us);
            dem[dangnhap] = 0;
        }
        int[] ar1 = new int[10];
        int m = Integer.parseInt(sc.nextLine());
        for(int i=0 ; i<m ; i++)
        {
            String[] str = sc.nextLine().split("\\s+");
            String dangnhap = str[0];
            String matkhau = str[1];
            for(User x : uss )
            {
                if(dangnhap.equals(x.dangnhap) && matkhau.equals(x.matkhau))
                {
                    dem[x.id - 1]++;
                    break;
                }
            }
        }
        for(int x : dem)
        {
            System.out.print(x + " ");
        }
        
    }
}


//4
//tendangnhap matkhau
//username password
//nguoidung m4tkh4un4yr4tb40m4t
//user2 password
//6
//tendangnhap matkhau
//username matkhau
//bfc34 contest
//username password
//tendangnhap matkhau
//user2 password